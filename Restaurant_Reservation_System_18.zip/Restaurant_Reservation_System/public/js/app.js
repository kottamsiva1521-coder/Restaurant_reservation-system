const tableList = document.getElementById("table-list");
const tableSelect = document.getElementById("table-select");
const bookingForm = document.getElementById("booking-form");
const bookingMessage = document.getElementById("booking-message");
const reservationList = document.getElementById("reservation-list");

const today = new Date();
const localToday = new Date(today.getTime() - today.getTimezoneOffset() * 60000)
    .toISOString().split("T")[0];
document.getElementById("reservation-date").min = localToday;

async function loadTables() {
    try {
        const response = await fetch("/api/tables");
        const tables = await response.json();

        tableList.innerHTML = "";
        tableSelect.innerHTML = '<option value="">Choose a table</option>';

        tables.forEach(table => {
            const card = document.createElement("article");
            card.className = "table-card";
            card.innerHTML = `
                <h3>Table ${escapeHtml(table.table_number)}</h3>
                <p>Seating capacity: ${table.seating_capacity} guests</p>
                <p>Location: ${escapeHtml(table.location)}</p>
                <span class="table-status">${escapeHtml(table.status)}</span>
            `;
            tableList.appendChild(card);

            const option = document.createElement("option");
            option.value = table.table_id;
            option.textContent = `${table.table_number} - ${table.seating_capacity} seats`;
            tableSelect.appendChild(option);
        });
    } catch (error) {
        tableList.textContent = "Could not load tables. Check the server.";
    }
}

async function loadReservations() {
    try {
        const response = await fetch("/api/reservations");
        const reservations = await response.json();
        reservationList.innerHTML = "";

        if (reservations.length === 0) {
            reservationList.innerHTML = '<tr><td colspan="9">No reservations yet.</td></tr>';
            return;
        }

        reservations.forEach(item => {
            const row = document.createElement("tr");
            row.innerHTML = `
                <td>${item.reservation_id}</td>
                <td>${escapeHtml(item.name)}</td>
                <td>${escapeHtml(item.phone)}</td>
                <td>${escapeHtml(item.table_number)}</td>
                <td>${formatDate(item.reservation_date)}</td>
                <td>${String(item.reservation_time).slice(0, 5)}</td>
                <td>${item.guests}</td>
                <td>${escapeHtml(item.status)}</td>
                <td>
                    <select aria-label="Update reservation ${item.reservation_id}"
                        onchange="updateStatus(${item.reservation_id}, this.value)">
                        <option value="Confirmed" ${item.status === "Confirmed" ? "selected" : ""}>Confirmed</option>
                        <option value="Completed" ${item.status === "Completed" ? "selected" : ""}>Completed</option>
                        <option value="Cancelled" ${item.status === "Cancelled" ? "selected" : ""}>Cancelled</option>
                    </select>
                </td>
            `;
            reservationList.appendChild(row);
        });
    } catch (error) {
        reservationList.innerHTML = '<tr><td colspan="9">Could not load reservations.</td></tr>';
    }
}

bookingForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    bookingMessage.textContent = "Submitting your reservation...";
    bookingMessage.className = "message";

    const formData = new FormData(bookingForm);
    const data = Object.fromEntries(formData.entries());
    data.guests = Number(data.guests);

    try {
        const response = await fetch("/api/reservations", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(data)
        });
        const result = await response.json();

        if (!response.ok) throw new Error(result.message || "Booking failed.");

        bookingMessage.textContent =
            `${result.message} Your reservation ID is ${result.reservation_id}.`;
        bookingMessage.className = "message success";
        bookingForm.reset();
        document.getElementById("reservation-date").min = localToday;
        await loadReservations();
    } catch (error) {
        bookingMessage.textContent = error.message;
        bookingMessage.className = "message error";
    }
});

async function updateStatus(id, status) {
    try {
        const response = await fetch(`/api/reservations/${id}`, {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ status })
        });
        const result = await response.json();
        if (!response.ok) throw new Error(result.message);
        await loadReservations();
        alert(result.message);
    } catch (error) {
        alert(error.message || "Could not update status.");
        await loadReservations();
    }
}

function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, character => ({
        "&": "&amp;", "<": "&lt;", ">": "&gt;",
        '"': "&quot;", "'": "&#039;"
    })[character]);
}

function formatDate(value) {
    const date = new Date(`${String(value).slice(0, 10)}T00:00:00`);
    return date.toLocaleDateString();
}

document.getElementById("refresh-btn").addEventListener("click", loadReservations);

loadTables();
loadReservations();