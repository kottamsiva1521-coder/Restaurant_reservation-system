# Restaurant Table Reservation Management System - Siva

A beginner-friendly Full Stack Development mini project built with HTML, CSS, JavaScript, Node.js, Express.js and MySQL.

## Features

- Display restaurant tables and seating capacity
- Customer reservation form
- Save customer and reservation details in MySQL
- Prevent a duplicate booking for the same table, date and time
- View all reservations in the staff section
- Update reservation status: Confirmed, Completed or Cancelled

## Requirements

- Node.js (recommended: Node.js 20 or later)
- MySQL Server
- Visual Studio Code

## Step 1: Open the project

Extract the ZIP file and open the `Restaurant_Reservation_System` folder in VS Code.

## Step 2: Create the database

1. Start MySQL Server.
2. Open MySQL Workbench or the MySQL command line.
3. Open `database.sql`.
4. Execute the complete SQL script.

This creates `restaurant_db`, the `customers`, `restaurant_tables` and `reservations` tables, and six sample restaurant tables.

## Step 3: Configure the database connection

1. In the project root, create a file named `.env`.
2. Copy the contents of `.env.example` into `.env`.
3. Change `DB_PASSWORD` to your actual MySQL password.

Example:

```env
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_actual_password
DB_NAME=restaurant_db
PORT=3000
```

If your MySQL root account has no password, leave the value empty after `DB_PASSWORD=`.

## Step 4: Install packages

Open the VS Code terminal in the project folder and run:

```bash
npm install
```

## Step 5: Start the project

```bash
npm start
```

When the terminal says the server is running, open:

http://localhost:3000

For development with automatic restart:

```bash
npm run dev
```

## Step 6: Test the project

1. View the six sample tables.
2. Fill in the reservation form.
3. Submit a booking.
4. Scroll to the Staff section to view the booking.
5. Change its status and refresh the list.
6. Try booking the same table at the same date and time to see the duplicate-booking check.

## Project folder structure

```text
Restaurant_Reservation_System/
├── public/
│   ├── css/
│   │   └── style.css
│   ├── js/
│   │   └── app.js
│   └── index.html
├── routes/
├── database.sql
├── server.js
├── package.json
├── .env.example
├── .gitignore
└── README.md
```

## GitHub upload

Create a new empty repository on GitHub. Then run these commands in the project terminal (replace the URL with your own repository URL):

```bash
git init
git add .
git commit -m "Add restaurant reservation system"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

Do not upload your `.env` file. It is excluded through `.gitignore`.

## Important classroom note

This is a learning/demo project. The staff page is not protected by login, and the duplicate-booking check compares exact date and time values. Add authentication, authorization, stronger validation and booking-duration conflict checks before real-world deployment.
