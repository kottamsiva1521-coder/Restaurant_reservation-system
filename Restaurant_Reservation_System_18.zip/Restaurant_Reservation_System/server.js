const express = require("express");
const mysql = require("mysql2/promise");
const path = require("path");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const dbConfig = {
    host: process.env.DB_HOST || "localhost",
    user: process.env.DB_USER || "root",
    password: process.env.DB_PASSWORD || "",
    database: process.env.DB_NAME || "restaurant_db"
};

let pool;

async function startServer() {
    try {
        pool = mysql.createPool({
            ...dbConfig,
            waitForConnections: true,
            connectionLimit: 10,
            dateStrings: true
        });

        await pool.query("SELECT 1");
        console.log("Connected to MySQL database.");

        app.listen(PORT, () => {
            console.log(`Server running at http://localhost:${PORT}`);
        });
    } catch (error) {
        console.error("Could not connect to MySQL.");
        console.error("Check MySQL is running and your .env database settings are correct.");
        console.error(error.message);
        process.exit(1);
    }
}

// Show all restaurant tables
app.get("/api/tables", async (req, res) => {
    try {
        const [rows] = await pool.query(
            "SELECT * FROM restaurant_tables ORDER BY table_id"
        );
        res.json(rows);
    } catch (error) {
        res.status(500).json({ message: "Unable to load tables." });
    }
});

// Create a reservation
app.post("/api/reservations", async (req, res) => {
    const { name, email, phone, table_id, reservation_date,
            reservation_time, guests } = req.body;

    if (!name || !email || !phone || !table_id ||
        !reservation_date || !reservation_time || !guests) {
        return res.status(400).json({ message: "Please fill in all fields." });
    }

    const guestCount = Number(guests);
    const selectedTable = Number(table_id);

    if (!Number.isInteger(guestCount) || guestCount < 1 ||
        !Number.isInteger(selectedTable)) {
        return res.status(400).json({ message: "Please enter valid booking details." });
    }

    const connection = await pool.getConnection();
    try {
        await connection.beginTransaction();

        const [tables] = await connection.query(
            "SELECT seating_capacity FROM restaurant_tables WHERE table_id = ? FOR UPDATE",
            [selectedTable]
        );

        if (tables.length === 0) {
            await connection.rollback();
            return res.status(404).json({ message: "Selected table was not found." });
        }

        if (guestCount > tables[0].seating_capacity) {
            await connection.rollback();
            return res.status(400).json({
                message: `This table can seat only ${tables[0].seating_capacity} guests.`
            });
        }

        const [existing] = await connection.query(
            `SELECT reservation_id FROM reservations
             WHERE table_id = ? AND reservation_date = ?
             AND reservation_time = ? AND status <> 'Cancelled'`,
            [selectedTable, reservation_date, reservation_time]
        );

        if (existing.length > 0) {
            await connection.rollback();
            return res.status(409).json({
                message: "This table is already booked for that date and time. Please choose another."
            });
        }

        const [customerResult] = await connection.query(
            "INSERT INTO customers (name, email, phone) VALUES (?, ?, ?)",
            [name.trim(), email.trim(), phone.trim()]
        );

        const [reservationResult] = await connection.query(
            `INSERT INTO reservations
             (customer_id, table_id, reservation_date, reservation_time, guests, status)
             VALUES (?, ?, ?, ?, ?, 'Confirmed')`,
            [customerResult.insertId, selectedTable, reservation_date,
             reservation_time, guestCount]
        );

        await connection.commit();
        res.status(201).json({
            message: "Reservation booked successfully!",
            reservation_id: reservationResult.insertId
        });
    } catch (error) {
        await connection.rollback();
        console.error(error);
        res.status(500).json({ message: "Could not create reservation." });
    } finally {
        connection.release();
    }
});

// View all reservations (staff view)
app.get("/api/reservations", async (req, res) => {
    try {
        const [rows] = await pool.query(
            `SELECT r.reservation_id, c.name, c.email, c.phone,
                    t.table_number, r.reservation_date, r.reservation_time,
                    r.guests, r.status
             FROM reservations r
             JOIN customers c ON r.customer_id = c.customer_id
             JOIN restaurant_tables t ON r.table_id = t.table_id
             ORDER BY r.reservation_date DESC, r.reservation_time DESC`
        );
        res.json(rows);
    } catch (error) {
        res.status(500).json({ message: "Unable to load reservations." });
    }
});

// Update reservation status
app.patch("/api/reservations/:id", async (req, res) => {
    const { status } = req.body;
    const allowed = ["Confirmed", "Completed", "Cancelled"];

    if (!allowed.includes(status)) {
        return res.status(400).json({ message: "Invalid reservation status." });
    }

    try {
        const [result] = await pool.query(
            "UPDATE reservations SET status = ? WHERE reservation_id = ?",
            [status, req.params.id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Reservation not found." });
        }

        res.json({ message: "Reservation status updated." });
    } catch (error) {
        res.status(500).json({ message: "Unable to update reservation." });
    }
});

startServer();