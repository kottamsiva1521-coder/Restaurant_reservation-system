CREATE DATABASE IF NOT EXISTS restaurant_db;
USE restaurant_db;

CREATE TABLE IF NOT EXISTS customers (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(15) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS restaurant_tables (
    table_id INT AUTO_INCREMENT PRIMARY KEY,
    table_number VARCHAR(20) NOT NULL UNIQUE,
    seating_capacity INT NOT NULL,
    location VARCHAR(50) DEFAULT 'Main Hall',
    status VARCHAR(20) DEFAULT 'Available'
);

CREATE TABLE IF NOT EXISTS reservations (
    reservation_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    table_id INT NOT NULL,
    reservation_date DATE NOT NULL,
    reservation_time TIME NOT NULL,
    guests INT NOT NULL,
    status VARCHAR(30) DEFAULT 'Confirmed',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_reservation_customer FOREIGN KEY (customer_id)
        REFERENCES customers(customer_id) ON DELETE CASCADE,
    CONSTRAINT fk_reservation_table FOREIGN KEY (table_id)
        REFERENCES restaurant_tables(table_id) ON DELETE RESTRICT
);

INSERT IGNORE INTO restaurant_tables
(table_number, seating_capacity, location, status) VALUES
('T1', 2, 'Window Side', 'Available'),
('T2', 2, 'Main Hall', 'Available'),
('T3', 4, 'Main Hall', 'Available'),
('T4', 4, 'Garden Side', 'Available'),
('T5', 6, 'Garden Side', 'Available'),
('T6', 8, 'Family Area', 'Available');

-- ---------- Sample customers (added only if not already present) ----------
INSERT INTO customers (name, email, phone)
SELECT v.n, v.e, v.p FROM (
    SELECT 'Siva' AS n, 'siva@example.com' AS e, '9876543210' AS p
    UNION ALL SELECT 'Kiran', 'kiran@example.com', '9876500001'
    UNION ALL SELECT 'Anitha', 'anitha@example.com', '9876500002'
    UNION ALL SELECT 'Ravi', 'ravi@example.com', '9876500003'
    UNION ALL SELECT 'Meena', 'meena@example.com', '9876500004'
) v
WHERE NOT EXISTS (SELECT 1 FROM customers c WHERE c.email = v.e);

-- ---------- Sample reservations (dates are relative to today, so they stay upcoming) ----------
INSERT INTO reservations (customer_id, table_id, reservation_date, reservation_time, guests, status)
SELECT c.customer_id, t.table_id, DATE_ADD(CURDATE(), INTERVAL v.d DAY), v.tm, v.g, v.st
FROM (
    SELECT 'siva@example.com' AS e, 'T3' AS tn, 1 AS d, '19:00:00' AS tm, 4 AS g, 'Confirmed' AS st
    UNION ALL SELECT 'siva@example.com',   'T1', 3, '20:00:00', 2, 'Confirmed'
    UNION ALL SELECT 'kiran@example.com',  'T5', 1, '13:00:00', 6, 'Confirmed'
    UNION ALL SELECT 'anitha@example.com', 'T4', 2, '18:30:00', 4, 'Confirmed'
    UNION ALL SELECT 'ravi@example.com',   'T6', 4, '20:30:00', 8, 'Confirmed'
    UNION ALL SELECT 'meena@example.com',  'T2', 2, '12:30:00', 2, 'Cancelled'
    UNION ALL SELECT 'kiran@example.com',  'T3', 0, '12:00:00', 3, 'Completed'
) v
JOIN customers c ON c.email = v.e
JOIN restaurant_tables t ON t.table_number = v.tn
WHERE NOT EXISTS (
    SELECT 1 FROM reservations r
    WHERE r.customer_id = c.customer_id AND r.table_id = t.table_id
      AND r.reservation_date = DATE_ADD(CURDATE(), INTERVAL v.d DAY)
      AND r.reservation_time = v.tm
);
